﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GradientBG : MonoBehaviour
{

    // Start is called before the first frame update
    public RawImage img;
    private Texture2D backgroundTexture;
    public Color[] listColor;
    

    void Awake()
    {
        img = GetComponent<RawImage>();
        backgroundTexture = new Texture2D(1, 2);
        backgroundTexture.wrapMode = TextureWrapMode.Clamp;
        backgroundTexture.filterMode = FilterMode.Bilinear;
        SetColor();
    }

    public void SetColor()
    {
        backgroundTexture.SetPixels(listColor);
        backgroundTexture.Apply();
        img.texture = backgroundTexture;
    }
}

   
