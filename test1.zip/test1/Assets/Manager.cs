﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class Manager : MonoBehaviour
{

//============================Prime Number Generator Variable=======================
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }

//=================================Reverse String=======================
    public TMP_Text txReverseResult;
    private string sReversedInput;
    public string sReversedDefaultValue;

    public void inputTextToRevese(string s)
    {
        sReversedInput = s;
    }
    public void setReverseToDefaultValue() {
        txPrimeResult.text = sReversedDefaultValue;
    }

    public void ReverseString() {
        char[] charInput = sReversedInput.ToCharArray();
        for(int i = 0; i < charInput.Length/2; i++)
        {

            char cTemp = charInput[i];
            charInput[i] = charInput[charInput.Length-1-i];
            charInput[charInput.Length - 1 - i] = cTemp;
        }
        txReverseResult.text = new string(charInput);
            
    }


 //============================Prime Number Generator=======================
    public TMP_Text txPrimeResult;
    private int iPrimeInput;
    public string sPrimeDefaultValue;

    public void setPrimeToDefaultValue()
    {
        txPrimeResult.text = sPrimeDefaultValue;
    }
    public void inputTextToPrime(string s)
    {
        if (s != "")
        {
            iPrimeInput = int.Parse(s);
        }
    }

    public void GeneratePrimeNumber()
    {
        if (iPrimeInput <= 0)
        {
            txPrimeResult.text = "invalid";
        }
        else
        {
            string sPrime = "";
            ArrayList prime = new ArrayList();
            prime.Add(2);
            bool isPrime = false;

            int n = 2;
            for (int i = 2; i <= iPrimeInput;)
            {
                n++;                
                for(int j =0; j < prime.Count; j++)
                {
                    if (n %(int) prime[j] == 0)
                    {
                        isPrime = false;
                        break;
                    }
                    else
                    {
                        isPrime = true;
                    }                                           
                }
                if (isPrime)
                {
                    prime.Add(n);
                    i++;
                }
            }
           
            for (int k = 0; k < prime.Count; k++)
            {
                if (k == 0) {
                    sPrime = prime[k].ToString();
                } else
                {
                    sPrime = sPrime+ "," + prime[k];
                }
                
            }

            txPrimeResult.text = sPrime;

        }
    }
    //============================= Find Number Index==================

    
    public TMP_Text txNumberIndexResult,txFilledArray;
    public string sNumberIndexDefaultValue;
    public int[] numberIndexArray = new int[10];
    public int iNumberIndexTarget;

    public void FillArray()
    {
        string s="";
        for(int i = 0; i < numberIndexArray.Length; i++)
        {
            int randomNumber = Random.Range(0, numberIndexArray.Length);
            numberIndexArray[i] = randomNumber;
            s += randomNumber.ToString() + " ";

        }
        txFilledArray.text = s;
    }
    public void setNumberIndexToDefaultValue()
    {
        txNumberIndexResult.text = sNumberIndexDefaultValue;
    }
    public void inputTextIndexNumber(string s)
    {
        if (s != "")
        {
            iNumberIndexTarget = int.Parse(s);
        }
    }

    public void findNumber()
    {
        if (txFilledArray.text == "Random Array")
        {
            txNumberIndexResult.text = "Array Empty";
        }
        else 
        {
            txNumberIndexResult.text = GetIndexOfNumber(numberIndexArray, iNumberIndexTarget);
        }
    }
    private string GetIndexOfNumber(int[] arr, int targetNumber)
    {
        int secondindex = -1, lastindex=-1,countForSecond=0;
        
        for(int i = 0; i < arr.Length; i++)
        {

            
            if (arr[i] == targetNumber)
            {
                lastindex = i+1;
                countForSecond++;
                if(countForSecond == 2)
                {
                    secondindex = i+1;
                }
            }

        }
        string result = "Second sighting : index " + secondindex.ToString() +"\n" + 
            "Last sighting : index " + lastindex.ToString();

        return result;
    }

}
